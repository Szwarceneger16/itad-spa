import api from './apiEntity.js';
export default { api };